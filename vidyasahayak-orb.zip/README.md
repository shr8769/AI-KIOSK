# VidyaSahayak – AI Avatar Orb

> Fluid intelligence orb for PES University AI kiosk system.  
> WebGL fluid simulation · 9 AI states · Live mic reactivity · GPU accelerated · 60 fps

---

## File Structure

```
src/
└── components/
    └── orb/
        ├── index.ts              ← barrel export (import everything from here)
        ├── VidyaSahayakOrb.tsx   ← main React component
        ├── orbStates.ts          ← state definitions & config values
        ├── orbWebGL.ts           ← WebGL shader + uniform management
        ├── orbCanvas2D.ts        ← glass shell, membrane, aura (2D canvas)
        └── orbAudio.ts           ← Web Audio API mic analysis
└── app/
    └── page.tsx                  ← example integration page
```

---

## Quick Start

```bash
npm install
npm run dev
```

---

## Usage

### Minimal (auto-demo)
```tsx
import { VidyaSahayakOrb } from '@/components/orb';

export default function Page() {
  return <VidyaSahayakOrb />;
}
```

### Controlled by your backend
```tsx
import { useState } from 'react';
import { VidyaSahayakOrb } from '@/components/orb';
import type { OrbState } from '@/components/orb';

export default function KioskPage() {
  const [state, setState] = useState<OrbState>('idle');

  async function handleQuery(transcript: string) {
    setState('thinking');
    const docs = await fetchFromRAG(transcript);    // setState('retrieving') here
    const answer = await callLLM(transcript, docs); // setState('speaking') when TTS starts
    setState('idle');
  }

  return (
    <VidyaSahayakOrb
      state={state}
      onStateChange={setState}
      autoDemo={false}
      size={300}
    />
  );
}
```

---

## Props

| Prop | Type | Default | Description |
|---|---|---|---|
| `state` | `OrbState` | — | Controlled state from parent |
| `onStateChange` | `(s: OrbState) => void` | — | Callback on state change |
| `autoDemo` | `boolean` | `true` | Auto-cycle through all states on mount |
| `showLabels` | `boolean` | `true` | Show state name + description text |
| `showControls` | `boolean` | `true` | Show manual state buttons |
| `showMic` | `boolean` | `true` | Show microphone toggle button |
| `size` | `number` | `300` | Orb diameter in px |

---

## OrbState values

| State | When to use |
|---|---|
| `idle` | Kiosk waiting, attract loop |
| `detected` | Camera detects approaching user |
| `greeting` | Welcome message playing |
| `listening` | Microphone active, user speaking |
| `thinking` | LLM processing query |
| `retrieving` | RAG fetching from knowledge base |
| `clarifying` | Ambiguous query, asking follow-up |
| `speaking` | TTS output playing |
| `error` | System error / recovery |

---

## Customising states

Edit `orbStates.ts` — each state has these tunable parameters:

```ts
{
  energy:      0–1,   // overall brightness & intensity
  speed:       0–1,   // fluid animation speed
  convergence: 0–1,   // currents pull toward centre (thinking/retrieving)
  expansion:   0–1,   // energy expands outward (speaking/greeting)
  turb:        0–1,   // turbulence / chaos
  membrane:    0–1,   // surface deformation amount
  hueA/B/C:   degrees, // colour palette (blue family by default)
  sat:         0–1,   // colour saturation
  lum:         0–1,   // base luminance
  aura:        AuraMode,  // aura animation style
  mode:        FluidMode, // internal fluid current direction
}
```

---

## Mic reactivity

The orb listens to microphone input via Web Audio API. Voice amplitude drives:
- Membrane surface deformation (louder = stronger ripples)
- Internal turbulence increase
- Overall brightness lift
- Aura energy boost

The mic button is built into the component. You can also call `startMicAnalysis()` / `stopMicAnalysis()` directly from `orbAudio.ts` if you manage mic state externally.

---

## Performance

| Technique | Why |
|---|---|
| WebGL fragment shader | All per-pixel fluid math runs on GPU — zero CPU cost |
| 2D canvas glass + aura | Cheap gradient compositing, not per-pixel |
| Web Audio FFT 256 bins | Minimal CPU, plenty of frequency resolution |
| `smoothingTimeConstant: 0.72` | Prevents jitter without introducing lag |
| `easeInOut` state transitions | 1.6s lerp across all parameters — no hard cuts |

Tested at stable 60 fps with mic active on integrated Intel/Apple Silicon GPU.

---

## Browser support

Requires WebGL 1.0 and Web Audio API — supported in all modern browsers.  
HTTPS required for microphone access (standard for deployed kiosks).
